(function () { window.location.replace( thisUrl ); }).delay( 500 );
