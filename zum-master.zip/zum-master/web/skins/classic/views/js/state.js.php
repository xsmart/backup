var running = <?= $running?'true':'false' ?>;
var applying = <?= !empty($_REQUEST['apply'])?'true':'false' ?>;
