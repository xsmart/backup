ANPR
====

Automatic number plate recognition

Some test images:
https://www.dropbox.com/s/6njx0vw9h6bsctj/test_img.tar.gz
