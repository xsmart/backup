<?php
class Filter extends AppModel {
	public $useTable = 'Filters';
	public $primaryKey = 'Name';
}
?>
