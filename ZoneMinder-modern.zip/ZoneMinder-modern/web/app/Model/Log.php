<?php
class Log extends AppModel {
	public $useTable = 'Logs';
	public $primaryKey = 'TimeKey';
  }
?>
