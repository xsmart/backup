<?php
  class Bandwidth extends AppModel {
    public $useTable = false;
  }
?>
