<?php
  class Version extends AppModel {
    public $useTable = false;
  }
?>
