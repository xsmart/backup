Modern ZoneMinder Skin
=======
This web frontend to ZoneMinder is a complete rewrite of the classic frontend, based on CakePHP.
