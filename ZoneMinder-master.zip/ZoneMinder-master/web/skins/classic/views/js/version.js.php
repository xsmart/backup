var openZmWindow = <?= (isset($_REQUEST['action']) && $_REQUEST['action'] == "version" && $_REQUEST['option'] == "go")?'true':'false' ?>;
