var action = '<?= isset($_REQUEST['action'])?validJsStr($_REQUEST['action']):'' ?>';
var option = '<?= isset($_REQUEST['option'])?validJsStr($_REQUEST['option']):'' ?>';
